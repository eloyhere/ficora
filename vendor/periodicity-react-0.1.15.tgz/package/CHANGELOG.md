# Changelog

All notable changes to Periodicity React are recorded here. The format follows the spirit of Keep a Changelog,
and this project uses British English in its English documentation.

## [Unreleased]

## [0.1.15] - 2026-10-28

### Added

- `PeriodicityVirtualWaterfallLayout` adds adapter-backed virtual masonry. Cards supply heights through `getHeight` /
  `itemHeight` or a `WaterfallAdapter`; each card enters the shortest column and only the visible vertical window is
  mounted.
- Both waterfall layouts accept `slots.item`, which replaces the container around each card. The slot receives the
  default class names and placement style so virtual cards keep their absolute position.
- `PeriodicityAudio` renders the native `audio` element inside a themed shell with a cover tile, an optional title
  and subtitle, and a transport that covers play and pause, seeking with buffered progress, time, a mute toggle, a
  vertical volume rail, and playback speed. `controls="native"` hands the chrome to the browser, `rates` sets the
  offered speeds, `slots.controls` replaces the transport with a render function that receives the live state,
  labels, and actions, `slots.actions` adds chrome beside the title, and a string `title` also names the player for
  assistive technology when no `label` or `aria-label` is supplied.
- `PeriodicityHorizontalVideo` and `PeriodicityVerticalVideo` render the same themed player in 16:9 and 9:16
  frames. The frame, bar, buttons, seek track, and overlays use the page's surface and accent roles; the built-in
  bar covers play and pause, seeking, time, a mute toggle, an entry that opens a vertical volume rail, and full
  screen; clicking the video toggles the chrome with a centred play or pause affordance; and `slots.controls`
  replaces the bottom bar with a render function that receives the live state, labels, and actions.
  `slots.aboveControls` adds extra chrome directly above the bar and hides with it, leaving the built-in bar intact.
- `PeriodicityBarrage` floats comments over any wrapped content on a pointer-transparent, lane-based layer. It
  accepts `items`, `paused`, `direction`, `lanes`, `duration`, `stagger`, `repeat`, `bottomInset`, and
  `respectReducedMotion`, plus `slots.item` and `slots.overlay` for custom floating UI. Items share one
  pixels-per-millisecond speed, the scheduler keeps lanes clear so comments cannot overtake one another, and
  appending items joins the current stream. The moving layer is hidden from assistive technology behind a visually
  hidden transcript and stills under `prefers-reduced-motion` unless `respectReducedMotion` is disabled.
- `PeriodicityRing` is the Android-style circular indicator. Without a `value` the ring spins forever: the graphic
  rotates while the rounded arc grows, shrinks, and shifts, matching the Android loader; with a `value` it draws a
  determinate arc, and `showValue` paints the percentage in the centre. `size`, `thickness`, `tone`, `label`, and
  `showValue` cover the surface, and `ElementLoading` and `FullscreenLoading` now spin a `Ring`.
- `PeriodicityTerminal` renders a themed console with a transcript, a command input, and an icon-only send button.
  `onInput` reports every edit, `onChange` reports a non-empty command submitted with Enter or the button,
  `history` / `onHistoryChange` bind ArrowUp/ArrowDown recall, and the caller appends output to `lines`;
  `editable={false}` keeps a transcript-only console. The paper, chrome, border, prompt, cursor, and line tones are
  all semantic colour roles, and the transcript is exposed as a labelled `role="log"` region.
- `PeriodicitySeekBar` is an Android-style seek bar: a native range input under a painted track and thumb, with
  buffered secondary progress, optional tick marks, snapped steps, horizontal or vertical direction (`length` sizes
  vertical tracks), sizes and tones, a thumb ripple on hover and press, and `onSeekStart` / `onSeekEnd` callbacks.
- `PeriodicityFrame`, `PeriodicityFrameItem`, and `PeriodicityFramePage` provide an Android-style frame layout: items
  are absolutely positioned by `gravity`, `offsetX` / `offsetY`, `width` / `height`, and `zIndex`, while `FramePage`
  swaps page content inside one bounded frame with clipping.
- `PeriodicityForm` now adds a validation and submission pipeline to the native form: `validate(values)` returns
  field errors, `onValidSubmit(values, api)` runs only when validation passes, async submissions keep the form
  `pending`, and the shared error map lets one server response mark every `FormField`. The new
  `PeriodicityFormMessage` reports a rejection in a focusable alert, `PeriodicityFormSubmit` disables itself and
  spins a `Ring` while pending, and an invalid submission focuses the message before the first invalid control.
- The showcase adds a `#media` family with the audio player, both video players, the custom control-bar slot,
  `SeekBar`, and the barrage overlay; the barrage demo mounts a `PeriodicityForm` composer in
  `slots.aboveControls` so it opens and closes with the player chrome, and an icon-only send button appends
  comments to the live stream. The virtual waterfall on the Layout page, `Ring` on Feedback, `SeekBar` on Choices,
  and `Terminal` on Documents are also documented.

### Changed

- Every CSS animation and transition now reads the shared motion layer. Durations multiply by `--motion-scale`,
  loops use `--motion-repeat`, and easing aliases point at the `--motion-ease-*` tokens, so one
  `PeriodicityAnimation` scope controls ripples, spinners, rings, skeletons, overlays, and icon effects together.
  The showcase opts into `<html data-motion="always">` so its demos stay animated when the host reports reduced
  motion; consumers keep the operating-system default.
- Indeterminate loading indicators use `--motion-essential-scale`. They keep a slower turn under reduced motion
  instead of freezing, so `Ring`, `Spinner`, the combobox spinner, and the confirm-dialog spinner always signal
  that work is in progress.
- `PeriodicityNavigationView` is now `PeriodicityNavigation`. The element, its props, and the `NavigationViewHandle`
  ref API are unchanged; hashes `#navigation-view` and `#navigationview` still resolve, and `#navigation` now opens
  the component itself.
- `WaterfallLayout` now lives under `src/layout/waterfall/normal`; the waterfall barrel and the public
  `PeriodicityWaterfallLayout` export resolve from the new location, and `PeriodicityVirtualWaterfallLayout` ships
  beside it.

### Removed

- `PeriodicityProgressRing` and `PeriodicityCircularProgress` were removed in favour of `PeriodicityRing`, which
  covers both the gauge and the loader; `PeriodicityCyclePicker` is unchanged.

### Fixed

- Anchored dropdowns, selects, popovers, and tooltips now share the anchor tracker used by the loading mask. The
  target is measured every frame, including visual-viewport scroll and resize, layout transitions, and keyboard
  changes, so the floating layer cannot remain at an old viewport coordinate.
- `ElementLoading` uses the same anchor tracker for its mask. The overlay follows its target during scrolling,
  viewport changes, and layout shifts, and hides while the target is outside the visual viewport instead of
  covering the wrong element.
- Dropdown panels cap their height to the space on the resolved side and keep the panel clear of the trigger when
  the visual viewport becomes short, instead of clamping over the anchor.
- `PeriodicityDateTimePicker` now renders the year and month fields in its calendar header with `NumberInput`, so
  both keep their labels and native number semantics while gaining the shared input layout and its stepper controls.

## [0.1.14] - 2026-10-28

### Added

- `PeriodicityStickyPage` is the page wrapper for sticky layouts. Built on `PeriodicityScroll`, its slot accepts any
  number of children, and the `PeriodicitySticky` layers inside pin against the page viewport.
- `PeriodicityScroll` is an Android-`ScrollView`-style layout: one vertical scroll viewport, one content block, any
  number of slot children, and `fillViewport`. It is the scroll layer used by `StickyPage`.
- `PeriodicitySticky` accepts `filter` with native CSS `filter` semantics, applied to the sticky subtree (the child
  page content) without affecting the scrollbar or focus ring.
- The showcase Sticky entry is now a routed homepage: a sticky site navigation, a stacking hero/statement sequence,
  and a sticky product media column with scrolling feature copy. Features and pricing are separate nested routes.

### Changed

- `PeriodicityScroll` now names the Android-ScrollView-style layout. The previous `Scroll` alias of `Scrollbar` was
  removed; use `PeriodicityScrollbar` (which still accepts the scrollbar `slots` prop) for overlay scrolling.

## [0.1.13] - 2026-10-28

### Added

- `PeriodicitySticky` pins a block to the top or bottom edge of its nearest scroll container while preserving its
  space in normal flow. `edge`, `offset`, `zIndex`, `disabled`, `stuckClassName`, and `onStuckChange` cover the
  pinning contract, and the element exposes `data-edge` and `data-stuck` for styling and tests.
- The showcase adds a dedicated `#sticky` route whose first demo is a self-contained mini site: its internal
  Overview, Guide, and Reference sub-pages share one scroll port with a sticky page header, a sticky contents rail,
  and a bottom-sticky action bar.

### Fixed

- Component routes now scroll to a demo with a gap below the sticky focus bar, so the demo title and description are
  no longer tucked underneath it.

## [0.1.12] - 2026-10-23

### Added

- `MessageList`, `VirtualMessageList`, `Chat`, and `VirtualChat` accept emoji-based `reactions` (including Like
  and Dislike) rendered in each message footer alongside the timestamp and delivery state. The quick choices form
  one native radio group, and a trailing more button opens the remaining emoji packs in a popover.
- `Chat` and `VirtualChat` now render their composer as one card: a borderless native textarea, an emoji popover,
  native file selection, screenshot capture, and an icon send button. Chosen files and screenshots are reported
  through `onSendFiles`.
- `Chat` and `VirtualChat` accept a conversation-centric source: `ChatConversation`, `ChatMessage`, and the plain or
  indexed `ChatDataSource` built with `createChatDataSource`. The sidebar shows previews, last-activity labels, and
  unread badges, while transcripts filter by `conversationId`; the legacy `contacts` and `messages` props still work.
- `AgentChat` and `VirtualAgentChat` add an agent workspace on top of the chat layouts. The left pane lists historical
  sessions, agent answers render Markdown, and reasoning appears in a separate collapsible view that expands with a
  height and opacity transition at a stable width. Streaming messages use a typewriter reveal with an animated caret,
  controlled by `typingSpeed`.

### Fixed

- Virtual message rows now default to 136px so timestamps, delivery state, and inline reactions stay visible.

## [0.1.11] - 2026-10-23

### Added

- `Markdown` renders read-only Markdown documents as sanitised, semantic HTML. Headings, nested lists, tables,
  quotes, fenced code, task lists, links, and images are supported; raw HTML is escaped and links and images are
  limited to safe URL schemes.
- `Tex` renders TeX mathematics as native MathML, so formulas stay selectable, scalable, and accessible to
  assistive technology.
- `Tex` now renders complete LaTeX documents (`\begin{document}`) as an HTML article with title, authors, abstract,
  numbered sections and appendix, lists, tables, figures, footnotes, citations, cross-references, and embedded
  MathML. Preamble `\newcommand`, `\renewcommand`, `\def`, and `\DeclareMathOperator` definitions are expanded.

### Fixed

- Hardened the file preview HTML sanitizer: descendants of unwrapped containers such as `svg`, `math`, `marquee`,
  and `details` are now sanitised before they move into the preview. Previously, a crafted HTML file could keep
  `javascript:` URLs or event-handler attributes alive through such a container.
- `Markdown`, `Tex`, and the file preview now reject control characters in URLs.

## [0.1.10] - 2026-10-22

### Added

- `HighFlyer` company icon for 幻方量化, and a redrawn `DeepSeek` whale mark for the agent set.
- Twenty redrawn animal glyphs (`AnimalLion` … `AnimalDolphin`) now live in the `Animal` category, which holds
  30 icons; the `AnimalExtra` category is gone.
- The Foundations icon catalogue plays `Dynamic` SVG animations even when the operating system requests reduced
  motion.
- `Avatar` accepts an inline SVG (or any React node) as `src` alongside image URLs and base64 data URIs; custom
  content fills the circular frame and keeps the avatar's accessible name.

### Changed

- Redrew the weakest catalogue glyphs: `Copilot`, `Llama`, `Ernie`, `Yi`, `Alphabet`, `Dog`, `Horse`, `Notebook`,
  `Telescope`, `Stethoscope`, `Hammer`, `Screwdriver`, `Cup`, `Nervous`, and `Countdown`; `Piano` and `Guitar` now
  follow their Lucide shapes.
- Renamed icons whose names collided across categories, where the later definition silently replaced the earlier
  glyph: `Pulse` → `HeartRate` (Health), `Notebook` → `NotebookDevice` (Computer), and `Chip` → `Microchip`
  (Computer).
- The icon catalogue now lists 695 icons across 38 categories.

### Fixed

- Anchored dropdown/select panels, popovers, and tooltips now follow their trigger when layout changes outside
  scrolling or resizing, such as a `Coordinator` collapsing its hero under wheel input, instead of remaining at the
  old fixed viewport position.
- Dropdown/Select panels, popovers, and context menus now also dismiss when the browser window loses focus or the
  document becomes hidden, so a floating layer no longer stays open after switching to another window or hiding the
  app.
- A catalogue test now asserts that every icon name is unique, so two categories can no longer define the same name
  and render the wrong glyph.

## [0.1.9] - 2026-10-22

### Fixed

- Dropdown and popover panels now opt out of Electron window dragging with
  `-webkit-app-region: no-drag`, so a menu that overlaps a `-webkit-app-region: drag` app bar or
  collapsing hero still receives hover, click, and keyboard input across its whole surface.

## [0.1.8] - 2026-10-22

### Added

- Showcase component search: a `CompleteInput` in the filter bar suggests every documented component and opens the
  selected entry.
- `TextInput` accepts `rootRef` for its field root, which lets composite fields anchor overlays without an extra
  wrapper element.
- Pointer-origin focus border ripple on the shared input shell: a radial wave from the pointer (or keyboard caret)
  reveals the nearest edge first, and every edge grows outward from its projection point; empty fields start from
  the centre and the wave eases out over one second.
- Per-item render slots for the messaging family: `Contact`/`VirtualContact` expose `contact` and `context`,
  `MessageList`/`VirtualMessageList` expose `message`, `messageContext`, and `avatar`, and `Chat`/`VirtualChat`
  forward all five. Each slot receives the rendered index and the item.
- `CommentThread` accepts a `comment` slot that replaces one whole comment item, and the new
  `VirtualCommentThread` virtualises the flattened thread at a fixed row height.
- `useFilePick` plus `FilePicker`, `PhotoPicker`, and `AvatarPicker`: native hidden file inputs, Base64 previews,
  an in-dialog cropper, pick/preview/avatar/crop slots, hover and click ripples, and one `change` event per
  completed selection. Photo and avatar edits emit on Confirm or Cancel, while closing the dialog aborts silently.
- `BarChart`, `PieChart`, `LineChart`, and `ScatterChart`: a responsive canvas and WebGL chart family with a
  WebGL-to-canvas fallback, device-pixel-ratio rendering, legends, screen-reader data tables, configurable
  palettes, and redraws scheduled through the shared task priority queue.
- `Font` and `useFont`: scoped typography levels, families, weights, line heights, letter spacing, transforms, and
  alignment, exposed through a nested font context.

### Changed

- `PeriodicityCompleteInput` and `PeriodicityMention` now render the same `InputLayout` field shell as `TextInput`,
  with the shared `prefix`, `hint`, `message`, `limitation`, `error`, and `suffix` slots. Mention's former
  below-field `hint` moved to `message`; `hint` is now the floating hint, and `leading`/`trailing` remain aliases
  for `prefix`/`suffix`. Complete no longer adds a wrapper element around the field.
- The input focus-border wave now plays even when the browser reports `prefers-reduced-motion: reduce`; the hint
  and background transitions still honour the preference.
- `PeriodicityNavigationView`'s bottom variant now measures its own width: it stays horizontal and scrolls sideways
  while at least two destinations fit, and switches to a vertical, scrollable list once only one fits. No manual
  variant switch is needed for narrow layouts.
- `PeriodicityCoordinator` now takes vertical wheel gestures over from content that cannot scroll, in the capture
  phase, so an inner component no longer swallows the gesture. Scrollable main content keeps native scrolling and
  still syncs the collapse area, header, and app bar; horizontal, Shift, and modified wheel gestures are ignored.
- Remaining hard-coded component copy now reads from `useInternational().t()`. A new typed `extraMessages` catalogue
  covers charts, pickers, comments, transfer, date-time, mention, rate, progress, radio, scrollbar, context menu,
  combobox, loading, and email/telephone validation copy for all 12 built-in locales.
- The showcase drops its left sidebar in favour of the top category filters and component search, adds a Charts
  page, keeps native + English labels in the language picker, and opts out of browser auto-translation so the
  authored language remains visible.

### Fixed

- `PeriodicityDrawerLayout` no longer consumes pointer events outside its root, so an external AppBar/Toolbar
  toggle can close and reopen the drawer; the scrim remains the dismiss surface. The layout is now positioned so
  the scrim stays inside it.
- Keep focus in `PeriodicityCompleteInput` while its suggestion panel is open, so the focused border stays
  visible and typing keeps filtering the suggestions.
- Close the `PeriodicityCompleteInput` suggestion panel and blur the field after a selection, instead of letting
  focus restoration reopen the panel.
- Cover the shared `InputLayout` shell in forced-colors mode, so every six-slot field keeps a system focus ring.
- `useFilePick` no longer treats a returning window focus as an immediate cancellation. It keeps listening for the
  native change event, polls the input files briefly, and only settles an empty selection after a short delay, so
  choosing an image reliably opens the crop dialog even when focus arrives before `change`.
- Canvas and WebGL chart colours resolve aliased CSS custom properties (`--color-primary: var(--accent)`) through
  computed styles, so theme palettes render correctly instead of falling back to black.
- Email and telephone fields pass localised validation messages into `validateEmail` and `validateTelephone`; both
  validators accept message overrides for callers that validate outside React.

## [0.1.7] - 2026-10-22

### Fixed

- Keep input focus when clicking inside an already focused field, so the border animation is not replayed.

## [0.1.6] - 2026-10-22

### Fixed

- Include generated TypeScript declarations in the published package again.

## [0.1.5] - 2026-10-22

### Fixed

- Animate all four input border edges independently from the pointer position over one second.

## [0.1.4] - 2026-10-22

### Fixed

- Use an editing cursor across the whole input field, while buttons and links keep their own cursor.

## [0.1.3] - 2026-10-22

### Added

- Six-slot text fields: prefix, floating hint, message, limitation, error, and suffix, with click-origin border animation.
- Compact prefix/content/suffix Button slots and the slot-based Toolbar mode.

### Fixed

- Focus the active input from anywhere in the field, including prefix and suffix icons.
- Ripple support on number steppers and whole-field colour picker activation.
- Contact row layout, CJK avatar initials, and localised presence labels.

## [0.1.2] - 2026-10-22

### Fixed

- Export the PeriodicityCalendarDaySlots type alias with the other calendar types.

## [0.1.1] - 2026-10-22

### Fixed

- Publish generated TypeScript declarations (dist/types) and a CSS module shim, so `types` and `exports.types` resolve for consumers.

## [0.1.0] - 2026-10-20

The first public npm release of `periodicity-react`.

### Highlights

- 130 prefixed React components covering forms, pickers, collections, overlays, navigation, messaging, file tools,
  theming, internationalisation, and motion.
- A publishable ES module build with TypeScript declarations and an extracted `styles.css`.
- Native attribute, event, ARIA, data-attribute, and ref pass-through across the component surface.
- Controlled and uncontrolled state, disabled/read-only/loading/empty states, and semantic callbacks throughout.
- Flex-first layout primitives; CSS Grid is not used.

### Added

- `Periodicity`-prefixed exports for every public component, including layouts and providers. The unprefixed names
  remain as compatibility aliases.
- `PeriodicityForm`, `PeriodicityFormField`, and `PeriodicityFormActions`: a native `<form>` wrapper with native
  validation/submission/reset behaviour, generated `label htmlFor` binding, `aria-describedby`, and `aria-invalid`
  wiring for native controls.
- `PeriodicityCoordinator`, `PeriodicityAppBar`, `PeriodicityCollapse`, and `PeriodicityToolbar`: a coordinated
  collapsing-hero app bar with exactly two Coordinator slots (`header` and `main`), a pinned toolbar, and
  scroll-driven progress.
- `PeriodicityCalendar`: locale-aware month grid with roving tabindex, ISO date values, range limits, Intl
  weekday/month labels, and arrow/Home/End/PageUp/PageDown selection.
- 23 global theme presets: `accessible`, `accessible-dark`, `protanopia`, `deuteranopia`,
  `tritanopia`, `achromatopsia`, `default`, `dark`, `milk`, `space-gray`, `gray`, `light-gray`,
  `sky-blue`, `pale-blue`, `deep-blue`, `orange`, `yellow`, `lemon`, `red`, `rose`, `green`,
  `deep-green`, and `light-green`, controlled through `theme`/`defaultTheme`/`setTheme`.
- `accessible-dark`: a dark high-contrast companion to `accessible` with white focus, strong borders, and a
  3px ring.
- Four colour-vision themes: `protanopia`, `deuteranopia`, `tritanopia`, and `achromatopsia`, using
  hue-independent or confusion-safe palettes.
- 12 built-in locales with common design-system messages, `localeOptions`, `builtInMessages`,
  `resolveLocaleMessages`, and locale direction: `en-GB`, `en-US`, `zh-CN`, `zh-SG`, `zh-HK`, `zh-TW`, `ja-JP`,
  `ko-KR`, `es-ES`, `es-MX`, `pt-PT`, and `pt-BR`.
- `Page` replaces `PagerPage` as the paged-route component.
- Accessibility improvements: form `aria-errormessage`/`aria-required`/combined descriptions, keyboard drag
  sorting, Scrollbar keyboard support, full calendar keyboard navigation, table/tree ARIA, overlay focus traps,
  skip link/landmarks, and high-contrast/forced-colors styles.
- Form controls: button, text input, text area, email, telephone, number, complete input, checkbox, radio group,
  range, switch, select, combobox, mention, and transfer.
- Pickers: colour, time, date-time, number, cycle, and variant.
- Collections: list, tree, table, select, combobox, and transfer variants, with adapter-backed data and optional
  fixed-row virtualisation.
- Overlays: dialog, confirm/message/input dialogs, drawer and drawer layout, context menu, dropdown, popover,
  tooltip, snackbar, toast, alert, banner, backdrop, and fullscreen/element loading.
- Navigation: navigation view, tabs and tab panels, pager, menu family, stepper, scrollbar, and drag sorting.
- Messaging: contact list, contact context menu, message list, message context menu, chat, and comment thread.
- File tooling: Markdown/HTML preview, code-structure preview, CodeMirror editor, and project manager.
- Design-system providers: theme, internationalisation, animation, and animated element wrappers.
- Display components: badge, chip, card, tag, avatar, avatar group, breadcrumbs, accordion, divider, empty state,
  pagination, progress, circular progress, progress ring, spinner, rate, skeleton, surface, text, thumb, and
  timeline.
- Native props and events, `ref` forwarding, `aria-*` and `data-*` support, and caller/internal handler composition
  across the component API.
- Controlled and uncontrolled variants for values, selection, expansion, open state, and provider configuration.
- Close reasons, focus restoration, escape handling, loading labels, empty states, and disabled states for the
  relevant overlays and collections.
- A custom SVG chart favicon used by the development server and static preview.

- Badge, Tag, Avatar, Link, and StateLayer now paint the shared ripple on pointer/keyboard activation; disabled badges, tags, avatars, and links suppress it. StateLayer forwards parent interaction when it is not already inside a Surface ripple.
- Common component defaults (dialogs, drawers, snackbars, alerts, pagination, dropdown/select, list/tree/table, file tools, calendar, contact/chat/message) now resolve through `useInternational().t()`, with 25 new common message keys in all 12 built-in locale dictionaries. Explicit caller props still win.

- Added `npm run audit:contrast`, `npm run audit:locales`, and `npm run test:a11y` as repeatable accessibility checks; the contrast audit covers `accessible`, `accessible-dark`, and the four colour-vision themes.
- Badge, Tag, Avatar, Link, and StateLayer ripples now answer both hover and press. Their colour is chosen from the effective surface luminance, and StateLayer measures contrast against its parent background.
- Alert, Tag, and Snackbar add an icon plus visually hidden status text as a second channel beyond colour; Toast keeps its tone icon.
- All 12 built-in dictionaries now carry every common message key (165 keys). Drawer edge labels, Calendar's Intl locale, and CodeBlock copy labels follow the active provider instead of hard-coded English.
- The documentation shell localises navigation, theme/language controls, About, skip link, back-to-top, and CodeBlock labels for all 12 locales.
- README and README.zh-CN are restructured around design philosophy, a function map, and components by function, with theme, accessibility-audit, and locale-audit documentation.

- Theme option labels now use the active locale instead of always showing Chinese · English, and component page titles show the API name plus its localised name (for example `Tag 标签`).
- Additional visible and accessible defaults now resolve through `t()`: breadcrumb expander, comment empty/loading states, context-menu and text-action labels, number stepper controls, time/date-time placeholders, hour/minute labels, comment loading, and toolbar back label.

- Documentation group/section labels and page descriptions now resolve per locale; en-US copy applies American spelling, and non-English descriptions use localised fallbacks instead of English catalogue copy.
- Localised component names are appended to the API name (`Tag 标签`, `Tag タグ`, `Tag Etiqueta`), and the component pickers use the same labels.
- The toolbar Select surfaces now declare their own background, so Surface ripple contrast is measured against the field rather than the blue AppBar.

### Changed

- `PagerPage` was renamed to `Page`; `PeriodicityPagerPage` is now `PeriodicityPage`. Route-based Pager usage and the
  showcase have been updated. This is a breaking rename for consumers that imported the old names.

- Package metadata now targets `periodicity-react@0.1.0`, with React 19 peer dependencies, public npm publishing,
  ES module and declaration entry points, and `periodicity-react/styles.css`.
- The library entry exports the full component barrel, and the library build extracts a single stylesheet under
  `dist/periodicity-react.css`.
- The showcase sidebar uses the library `Scrollbar` component instead of native scrollbar styling.
- Mention's floating label now uses the same explicit focused/filled/floating state model as TextField, including
  the outline notch and delayed placeholder.
- Drag sorting now renders a pointer-following ghost while preserving the existing six-pixel activation threshold
  and reorder callbacks.

### Fixed

- Dropdown and Select now render their option list through `Scrollbar`, with a visible track, stable gutter, and
  extra bottom padding so the final item can scroll fully into view. Dropdown panels no longer spawn a surface
  ripple.

- Editor selection colours no longer hide selected glyphs; native selection painting covers single-line, first-line,
  and last-line selections.
- Completion-related editor flicker and misplaced completion popups were removed together with the completion
  integration.
- Table uncontrolled selection now seeds from `defaultSelectedKeys`.
- Row keydown in List no longer double-toggles when the event originates inside a checkbox.
- Several event handlers that previously overwrote caller callbacks now compose them.

### Removed

- Code completion, N-gram completion, and the custom completion popup. Completion is left to LSP or dedicated editor
  integrations.
- The unused `@codemirror/autocomplete` direct dependency.

### Compatibility

- React 19 and React DOM 19 are required.
- Unprefixed component names continue to work as aliases, but new code should use the `Periodicity` prefix.
- Collection adapters, virtualisation configuration, and existing controlled APIs remain source-compatible.
- Markdown and HTML rendering is handled by the Preview component; CodeMirror remains an editor, not a renderer.

[Unreleased]: https://github.com/eloyhere/periodicity-react/compare/v0.1.15...HEAD
[0.1.15]: https://github.com/eloyhere/periodicity-react/compare/v0.1.14...v0.1.15
[0.1.14]: https://github.com/eloyhere/periodicity-react/compare/v0.1.13...v0.1.14
[0.1.13]: https://github.com/eloyhere/periodicity-react/compare/v0.1.12...v0.1.13
[0.1.12]: https://github.com/eloyhere/periodicity-react/compare/v0.1.11...v0.1.12
[0.1.11]: https://github.com/eloyhere/periodicity-react/compare/v0.1.10...v0.1.11
[0.1.10]: https://github.com/eloyhere/periodicity-react/compare/v0.1.9...v0.1.10
[0.1.9]: https://github.com/eloyhere/periodicity-react/compare/v0.1.8...v0.1.9
[0.1.8]: https://github.com/eloyhere/periodicity-react/compare/v0.1.7...v0.1.8
[0.1.7]: https://github.com/eloyhere/periodicity-react/compare/v0.1.6...v0.1.7
[0.1.6]: https://github.com/eloyhere/periodicity-react/compare/v0.1.5...v0.1.6
[0.1.5]: https://github.com/eloyhere/periodicity-react/compare/v0.1.4...v0.1.5
[0.1.4]: https://github.com/eloyhere/periodicity-react/compare/v0.1.3...v0.1.4
[0.1.3]: https://github.com/eloyhere/periodicity-react/compare/v0.1.2...v0.1.3
[0.1.2]: https://github.com/eloyhere/periodicity-react/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/eloyhere/periodicity-react/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/eloyhere/periodicity-react/releases/tag/v0.1.0
